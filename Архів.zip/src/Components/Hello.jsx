import World from "./World";

const Hello = () => {
    return (
        <>
            <span className="test">hello</span>
            <World/>
        </>
    )
};


export default Hello;