const Nav = () => {
  return (
    <ul className="nav">
      <div>asd</div>
      <div>asd</div>
      <div>asd</div>
      <div>asd</div>
      <div>asd</div>
      <div>sdasd</div>
      <input type="text" />
    </ul>
  );
};

export default Nav;
